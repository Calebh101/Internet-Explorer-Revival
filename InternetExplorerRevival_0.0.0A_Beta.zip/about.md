REVIVAL OF INTERNET EXPLORER
Version 0.0.0A

COMMAND LINE INPUT
"location_of_ie.vbs" "example.com"

Examples:
"C:\Program Files\IERevivalProgramFolder\ie.vbs" "youtube.com"
".\ie.vbs" "msn.com"