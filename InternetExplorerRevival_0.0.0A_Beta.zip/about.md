REVIVAL OF INTERNET EXPLORER
Version 0.0.0A
With Help of ChatGPT

I needed ChatGPT as I had no experience in Visual Basic or VBScript, but I constructed it.
This uses a technology called WebView to trick Windows to open Internet Explorer.

This project uses human-readable scripts, so it's open-source even if I didn't want it to.

COMMAND LINE INPUT
"location_of_ie.vbs" "example.com"

Examples:
"C:\Program Files\IERevivalProgramFolder\ie.vbs" "youtube.com"
".\ie.vbs" "msn.com"